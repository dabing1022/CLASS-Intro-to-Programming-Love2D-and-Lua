#include "InputHandler.h"

#include <vector>

#include <borka/InputManager.h>
#include <borka/Application.h>

void InputHandler::CheckInput()
{
    std::vector<bork::AppEvents> lstActions = bork::InputManager::GetEvents();

    for ( unsigned int i = 0; i < lstActions.size(); i++ )
    {
        if ( lstActions[i] == bork::APPLICATION_CLOSE )
        {
            bork::Application::Close();
        }
    }
}
