#include "AppState.h"
#include "InputHandler.h"

#include <borka/InputManager.h>
#include <borka/Renderer.h>
#include <borka/GraphicManager.h>
#include <borka/Application.h>

bool AppState::Init( bork::Window* window )
{
    bork::Renderer::Init( window );
    bork::InputManager::Init( window );

    bork::GraphicManager::AddGraphic( "Bush", ".png" );
    bork::GraphicManager::AddGraphic( "Gold", ".png" );
    bork::GraphicManager::AddGraphic( "Grass", ".png" );
    bork::GraphicManager::AddGraphic( "Sand", ".png" );
    bork::GraphicManager::AddGraphic( "Tree", ".png" );
    bork::GraphicManager::AddGraphic( "House1", ".png" );
    bork::GraphicManager::AddGraphic( "House2", ".png" );
    bork::GraphicManager::AddGraphic( "House3", ".png" );

    bork::InputManager::Init( window );

    bork::DrawableShape

    return true;
}

bool AppState::MainLoop()
{
    sf::Clock clock;
    float totalElapsedTime = 0;

    while ( bork::Application::IsOpened() )
    {
        InputHandler::CheckInput();

        bork::Renderer::Draw();

        float framerate = 1.f / clock.GetElapsedTime();
        totalElapsedTime += clock.GetElapsedTime();
        clock.Reset();
    }

    return true;
}


