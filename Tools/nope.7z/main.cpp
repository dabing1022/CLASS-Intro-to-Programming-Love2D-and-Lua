#include <borka/Application.h>
#include <borka/StateManager.h>

#include "AppState.h"

int main()
{
    bork::Application::Initialize( "Map Editor", 800, 600 );

    AppState appState;
    appState.Init( &bork::Application::GetWindow() );

    bork::StateManager::AddState( "App", &appState, true );

    appState.MainLoop();

    return 0;
}
