#ifndef INPUTHANDLER
#define INPUTHANDLER

class InputHandler
{
    public:
    static void CheckInput();
};

#endif
