#ifndef APPSTATE
#define APPSTATE

#include <borka/State.h>
#include <borka/Window.h>
#include <borka/Vector2f.h>

class AppState : public bork::State
{
    public:
    bool Init( bork::Window* window );
    bool MainLoop();
    void DrawGrid();

    private:
    bork::Vector2f m_screenOffset;
};

#endif
